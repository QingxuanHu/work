import time
import datetime

a1=datetime.datetime.now()
print(a1.second)


a2=datetime.datetime.now()
print((a2-a1).seconds)

