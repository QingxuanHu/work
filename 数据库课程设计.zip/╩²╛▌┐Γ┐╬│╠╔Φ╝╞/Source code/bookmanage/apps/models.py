from django.db import models

# Create your models here.

class User(models.Model):
    ID = models.CharField('账号', max_length=15, null=False,unique=True,primary_key=True)
    Name = models.CharField('姓名', max_length=15, null=False)
    password = models.CharField('密码', max_length=25, default='')
    identity = models.CharField('身份', max_length=10, null=False)
    sex = models.CharField('性别',max_length=10, null=False)
    institute = models.CharField('学院', max_length=50,null=False)
    record = models.IntegerField('不良记录数', default=0)
    fine = models.IntegerField('罚款',default=0)
    remain_num = models.IntegerField('剩余可借书的数量',default=4)

    class Meta:
        db_table = 'user'

class Administer(models.Model):

    ID = models.CharField('账号', max_length=15, null=False,unique=True,primary_key=True)
    Name = models.CharField('姓名', max_length=15, null=False)
    password = models.CharField('密码', max_length=25, default='')

    class Meta:
        db_table = 'administer'

class Book(models.Model):

    ID = models.CharField('书号', max_length=15, null=False,unique=True,primary_key=True)
    Name = models.CharField('书名', max_length=15, null=False)
    Author = models.CharField('作者', max_length=50, null=False)
    is_borrow=models.BooleanField('是否被借',default=False)

    class Meta:
        db_table = 'book'

class Borrow(models.Model):

    User_ID = models.CharField('账号', max_length=20, null=False)
    User_Name = models.CharField('名字', max_length=20, null=False)
    Book_ID = models.CharField('书号', max_length=20, null=False,primary_key=True)
    Book_Name =models.CharField('书名',max_length=20,null=False)
    Borrowing_Time=models.DateTimeField(auto_now_add=True)
    is_return=models.BooleanField('是否归还',default=False)
    is_overtime=models.BooleanField('是否超时',default=False)
    class Meta:
        db_table = 'borrow'


class Comment(models.Model):
    User_ID = models.CharField('账号', max_length=20, null=False)
    User_Name = models.CharField('名字', max_length=20, null=False)
    Book_ID = models.CharField('书号', max_length=20, null=False,primary_key=True)
    Book_Name =models.CharField('书名',max_length=20,null=False)
    Comment = models.TextField('评论',default='')
    class Meta:
        db_table = 'comment'

class Message(models.Model):
    User_ID = models.CharField('账号', max_length=20, null=False,primary_key=True)
    User_Name = models.CharField('名字', max_length=20, null=False)
    AD_ID = models.CharField('管理员号', max_length=20, null=False)
    AD_Name = models.CharField('管理员名字', max_length=20, null=False)
    Text = models.TextField('警告消息',default='')
    Time = models.DateTimeField(auto_now_add=True)  #警告时间，创建对象时自动填充时间
    class Meta:
        db_table = 'message'
