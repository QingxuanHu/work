from django.http import HttpResponse
from django.http import HttpRequest
from django.http import HttpResponseRedirect
from django.shortcuts import render,redirect
from apps.models import User,Book,Borrow,Comment,Message,Administer
from django.db.models import F,Q
from django.db.models import Count
from django.contrib import messages
import datetime
import time
import pytz

USERNAME=''
# Create your views here.
# 登录界面
def login(request):
    global USERNAME
    if request.method=='GET':
        return render(request,"login.html")  #默认会找apps/templates
    elif request.method=='POST':
        userID=request.POST['username']  #账号/用户名
        userpassword=request.POST['password']  #密码

        '''判断账户是否存在'''
        is_exist=User.objects.filter(ID=userID)
        is_exist_ad=Administer.objects.filter(ID=userID)
        if (is_exist or is_exist_ad):
            pass
        else:
            messages.success(request, '用户不存在')
            return render(request,"login.html")
            #return HttpResponse('用户不存在')

        '''判断是管理员还是用户'''
        is_exist=User.objects.filter(ID=userID)
        is_exist_ad=Administer.objects.filter(ID=userID)
        if is_exist_ad: #是管理员
            is_right_ad=Administer.objects.filter(Q(ID=userID)&Q(password=userpassword))
            if is_right_ad:

                news=Administer.objects.get(Q(ID=userID)&Q(password=userpassword))
                USERNAME=news.Name
                messages.success(request, '欢迎访问')
                return render(request,"base_ad.html",context={'hello':"欢迎"+news.Name+"管理员!"})  #去主页面
            else:
                messages.success(request, '密码错误')
                return render(request,"login.html")


        elif is_exist: # 是用户
            '''当前用户是否注册'''
            is_register=User.objects.filter(Q(ID=userID)&Q(password=''))
            if is_register:
                messages.success(request, '用户还没有注册')
                return render(request,"login.html")


            '''密码错误或者登录成功'''
            is_right=User.objects.filter(Q(ID=userID)&Q(password=userpassword))
            if is_right:
                news=User.objects.get(Q(ID=userID)&Q(password=userpassword))
                USERNAME=news.Name
                messages.success(request, '登陆成功,欢迎访问')
                return render(request,"base.html",context={'hello':"欢迎"+news.Name+news.identity+"!"})  #去主页面
            else:
                messages.success(request, '密码错误')
                return render(request, "login.html")

# 注册页面
def register(request):
    if request.method == 'GET':
        return render(request, "register.html")  # 默认会找apps/templates
    #POST 处理提交数据
    elif request.method == 'POST':
        userID = request.POST['username']  # 账号/用户名
        userpassword1 = request.POST['password1']  # 新密码
        userpassword2 = request.POST['password2']  #再次确认密码

        '''判断用户名是否存在'''
        is_exist=User.objects.filter(ID=userID)
        if (is_exist):
            pass
        else:
            return HttpResponse('用户不存在')

        '''当前用户是否已经注册'''
        old_users=User.objects.filter(Q(ID=userID)&~Q(password=''))
        if old_users:
            return HttpResponse('用户已注册过')

        '''两个密码要一样'''
        if userpassword1 != userpassword2:
            return HttpResponse('两次密码不一致')

        '''注册成功插入,插入密码'''
        newobject=User.objects.get(ID=userID)
        newobject.password=userpassword1
        newobject.save()
        messages.success(request, '注册成功')
        return render(request,"login.html")

# 主页面
def homepage(request):
    if request.method == 'GET':
        return render(request, "base.html")  # 默认会找apps/templates

# 书籍查询页面
def book_search(request):
    if request.method == 'GET':
        book_list = Book.objects.all()
        return render(request, "book_search.html",{"book_list":book_list})  # 默认会找apps/templates
    elif request.method=='POST':
        name_author=request.POST['name_author'].strip()
        author_list=Book.objects.filter(Author__contains=name_author)
        name_list=Book.objects.filter(Name=name_author)
        if name_list:
            book_list=name_list
            return render(request, "book_search.html",{"book_list":book_list})  # 默认会找apps/templates
        elif author_list:
            book_list = author_list
            return render(request, "book_search.html", {"book_list": book_list})  # 默认会找apps/templates
        else:
            return HttpResponse("不存在这样的书")

#个人信息查询
def person_search(request):
    global USERNAME
    if request.method == 'GET':
        inf_list = User.objects.filter(Name=USERNAME)
        return render(request, "person_search.html",{"inf_list":inf_list})  # 默认会找apps/templates
    elif request.method=='POST':
        return render(request, "person_edit.html")

#个人信息修改
def person_edit(request):
    if request.method == 'GET':
        return render(request, "person_edit.html")  # 默认会找apps/templates
    elif request.method=='POST':
        global USERNAME
        edit_password = request.POST['edit_password'].strip()
        edit_identity = request.POST['edit_identity'].strip()
        edit_sex = request.POST['edit_sex'].strip()
        edit_institute = request.POST['edit_institute'].strip()

        newobject=User.objects.get(Name=USERNAME)
        newobject.password=newobject.password if edit_password=='' else  edit_password
        newobject.identity = newobject.identity if edit_identity=='' else  edit_password
        newobject.sex = newobject if edit_sex=='' else edit_sex
        newobject.institue = newobject.institute if edit_institute=='' else edit_institute
        newobject.save()
        inf_list = User.objects.filter(Name=USERNAME)
        return render(request, "person_search.html",{"inf_list":inf_list})

#借书
def book_borrow(request):
    global  USERNAME
    if request.method == 'GET':
        book_borrow_list = Book.objects.filter(is_borrow=False)
        return render(request, "book_borrow.html",{"book_borrow_list":book_borrow_list})  # 默认会找apps/templates
    elif request.method=='POST':
        book_borrow_id=request.POST['book_borrow_id'].strip()

        '''书号不正确'''
        is_right=Book.objects.filter(ID=book_borrow_id)
        if is_right:
            pass
        else:
            book_borrow_list = Book.objects.filter(is_borrow=False)
            messages.success(request, '书号错误')
            return render(request, "book_borrow.html", {"book_borrow_list": book_borrow_list})  # 默认会找apps/templates

        '''书号正确，但已经被借走'''
        is_borrowed=Book.objects.filter(ID=book_borrow_id,is_borrow=False)
        if is_borrowed:
            pass
        else:
            book_borrow_list = Book.objects.filter(is_borrow=False)
            messages.success(request, '书已经被借走')
            return render(request, "book_borrow.html", {"book_borrow_list": book_borrow_list})  # 默认会找apps/templa

        '''书号正确，但已经不能借书了'''
        is_can=User.objects.filter(Name=USERNAME,remain_num__gt=0)
        if is_can:
            pass
        else:
            book_borrow_list = Book.objects.filter(Name=USERNAME,is_borrow=False)
            messages.success(request, '已借书的数量已达上限,不能再借书了')
            return render(request, "book_borrow.html", {"book_borrow_list": book_borrow_list})  # 默认会找apps/templa


        '''书号正确——有违规记录'''
        is_record=User.objects.filter(Name=USERNAME,record=0)
        if is_record:
            pass
        else:
            book_borrow_list = Book.objects.filter(Name=USERNAME, is_borrow=False)
            messages.success(request, '有违规记录，不能借书')
            return render(request, "book_borrow.html", {"book_borrow_list": book_borrow_list})  # 默认会找apps/templa

        '''书号正确——改变剩余可借书的数量'''
        change_num=User.objects.get(Name=USERNAME)
        change_num.remain_num=change_num.remain_num-1
        change_num.save()

        '''书号正确——将对应书的is_borrow改为true'''
        newbook = Book.objects.get(ID=book_borrow_id)
        newbook.is_borrow=True
        newbook.save()


        '''书号正确——增加一条借书记录'''
        #找userid：
        user=User.objects.get(Name=USERNAME)
        userid=user.ID

        #找bookname
        book=Book.objects.get(ID=book_borrow_id)
        bookname=book.Name

        book_borrow_list = Book.objects.filter(is_borrow=False)
        Borrow.objects.create(User_ID=userid, User_Name=USERNAME, Book_ID=book_borrow_id, Book_Name=bookname,
                              is_return=False)
        messages.success(request, '借书成功')
        return render(request, "book_borrow.html", {"book_borrow_list": book_borrow_list})

# 查看借书记录
def borrow_record(request):
    global  USERNAME
    if request.method == 'GET':
        borrow_record = Borrow.objects.filter(User_Name=USERNAME)
        return render(request, "borrow_record.html",{"borrow_record":borrow_record})

#还书页面
def book_return(request):
    global USERNAME
    if request.method == 'GET':
        book_return_list = Borrow.objects.filter(User_Name=USERNAME,is_return=False)  #展示没有还的书
        return render(request, "book_return.html", {"book_return_list": book_return_list})
    elif request.method == 'POST':
        book_return_id = request.POST['book_return_id'].strip()

        '''书号不正确'''
        is_right = Book.objects.filter(ID=book_return_id)
        if is_right:
            pass
        else:
            book_return_list = Borrow.objects.filter(User_Name=USERNAME,is_return=False)
            messages.success(request, '书号错误')
            return render(request, "book_return.html", {"book_return_list": book_return_list})  # 默认会找apps/templates

        '''书号正确，但该用户没有借'''
        is_borrowed = Borrow.objects.filter(User_Name=USERNAME, Book_ID=book_return_id)
        if is_borrowed:
            pass
        else:
            book_return_list = Borrow.objects.filter(User_Name=USERNAME, is_return=False)
            messages.success(request, '用户没有借这本书')
            return render(request, "book_return.html", {"book_return_list": book_return_list})  # 默认会找apps/templa

        '''书号正确，但用户已经还了'''
        is_return = Borrow.objects.filter(User_Name=USERNAME, Book_ID=book_return_id,is_return=False)
        if is_return:
            pass
        else:
            book_return_list = Borrow.objects.filter(User_Name=USERNAME, is_return=False)
            messages.success(request, '用户已经还了')
            return render(request, "book_return.html", {"book_return_list": book_return_list})

        '''书号正确，将书的is_return改为True,is_overtime改为False'''
        newobject1=Borrow.objects.get(User_Name=USERNAME,Book_ID=book_return_id,is_return=False)
        newobject1.is_return=True
        newobject1.save()

        '''书号正确，将书的is_borrow改为false'''
        newobject2 = Book.objects.get( ID=book_return_id, is_borrow=True)
        newobject2.is_borrow = False
        newobject2.save()

        '''书号正确，改变剩余可借书的数量'''
        newobject3 = User.objects.get(Name=USERNAME)
        newobject3.remain_num = newobject3.remain_num + 1
        newobject3.save()

        book_return_list = Borrow.objects.filter(User_Name=USERNAME, is_return=False)
        messages.success(request, '还书成功')
        return render(request, "book_return.html", {"book_return_list": book_return_list})

#缴费页面
def pay(request):
    global USERNAME
    names = []
    '''计算违规数+罚款+是否超时设置'''
    now=datetime.datetime.now()
    objects=Borrow.objects.filter(is_return=False,is_overtime=False) # 找到未归还的书且之前没有超时的
    for obj in objects:
        #如果它们超时了
        obj.is_overtime=True
        obj.save()
        names.append(obj.User_Name)
    #增加罚款
    for name in names:
        user = User.objects.get(Name=name)
        user.fine=user.fine+10
        user.record=user.record + 1
        user.save()

    #点击按钮请求
    userid = request.GET.get('id')
    user = User.objects.filter(ID=userid)
    for users in user:
        users.fine = 0
        users.record = 0
        users.save()

    chao_list = User.objects.filter(Q(record__gt=0) & Q(fine__gt=0))  # 筛选超时未还的书
    return render(request, "pay.html", {"chao_list": chao_list})

#书籍评论
def comment(request):
    global USERNAME
    if request.method == 'GET':
        comment_list = Book.objects.all()
        return render(request, "comment.html",{"comment_list":comment_list})  # 默认会找apps/templates
    elif request.method=='POST':
        bookid=request.POST['bookid'].strip()
        content = request.POST['content'].strip()

        '''书号输入错误'''
        is_wrong=Book.objects.filter(ID=bookid)
        if (is_wrong):
            pass
        else:
            messages.success(request, '书号输入错误')
            comment_list = Book.objects.all()
            return render(request, "comment.html",{"comment_list":comment_list})

        '''书号输入正确'''
        user = User.objects.get(Name=USERNAME)
        userid = user.ID

        # 找bookname
        book = Book.objects.get(ID=bookid)
        bookname = book.Name
        #创建comment对象
        Comment.objects.create(User_ID=userid, User_Name=USERNAME, Book_ID=bookid, Book_Name=bookname,
                              Comment=content)

        messages.success(request, '评论成功')
        comment_result_list = Comment.objects.filter(User_Name=USERNAME)
        return render(request, "comment_result.html",{"comment_result_list":comment_result_list})
        return render(request, "comment_result.html")


#评论结果查询
def comment_result(request):
    global USERNAME
    if request.method == 'GET':
        comment_result_list = Comment.objects.filter(User_Name=USERNAME)
        return render(request, "comment_result.html",{"comment_result_list":comment_result_list})
    elif request.method == 'POST':
        comment_list = Book.objects.all()
        return render(request, "comment.html",{"comment_list":comment_list})

#消息查看
def message_search(request):
    global USERNAME
    if request.method == 'GET':
        message_record = Message.objects.filter(User_Name=USERNAME)
        return render(request, "message_search.html", {"message_record": message_record})



#管理员查看所有借书记录
def ad_borrow_record(request):
    if request.method == 'GET':
        ad_borrow_record = Borrow.objects.all()
        return render(request, "ad_borrow_record.html", {"ad_borrow_record": ad_borrow_record})

#管理员发送消息
def ad_message(request):
    global USERNAME
    if request.method == 'GET':
        user_list = User.objects.all()
        return render(request, "ad_message.html",{"user_list":user_list})  # 默认会找apps/templates
    elif request.method=='POST':
        userid=request.POST['userid'].strip()
        message = request.POST['message'].strip()

        '''用户输入错误'''
        is_wrong=User.objects.filter(ID=userid)
        if (is_wrong):
            pass
        else:
            messages.success(request, '用户账号输入错误')
            user_list = User.objects.all()
            return render(request, "ad_message.html",{"user_list":user_list})

        '''用户号输入正确'''
        #找用户名字
        user = User.objects.get(ID=userid)
        username = user.Name

        # 找管理员号
        ad = Administer.objects.get(Name=USERNAME)
        adid = ad.ID
        #创建Message对象
        Message.objects.create(User_ID=userid, User_Name=username, AD_ID=adid, AD_Name=USERNAME,Text=message)
        messages.success(request, '发送成功')
        message_result_list = Message.objects.filter(AD_Name=USERNAME)
        return render(request, "ad_message_result.html",{"message_result_list":message_result_list})

#发送消息成功页面
def ad_message_result(request):
    global USERNAME
    if request.method == 'GET':
        message_result_list = Message.objects.filter(AD_Name=USERNAME)
        return render(request, "ad_message_result.html",{"message_result_list":message_result_list})
    elif request.method == 'POST':
        user_list = User.objects.all()
        return render(request, "ad_message.html",{"user_list":user_list})



























