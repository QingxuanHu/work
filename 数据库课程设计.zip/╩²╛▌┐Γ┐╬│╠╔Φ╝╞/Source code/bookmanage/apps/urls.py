from django.urls import path
from apps import views
urlpatterns = [
    path('login', views.login),  #登录界面
    path('register', views.register),  # 注册界面
    path('homepage',views.homepage),    # 主页面
    path('book_search',views.book_search), #书籍查询页面
    path('person_search',views.person_search), #个人信息查询页面
    path('person_edit',views.person_edit), #个人信息修改页面
    path('book_borrow',views.book_borrow), #借书
    path('borrow_record',views.borrow_record), #借书
    path('book_return',views.book_return), #还书
    path('pay',views.pay), #缴费
    path('comment',views.comment), # 书籍评论
    path('comment_result',views.comment_result),  #评论结果
    path('message_search',views.message_search),  #消息查看
    path('ad_borrow_record',views.ad_borrow_record),  #管理员查看借书记录
    path('ad_message',views.ad_message),  #发消息给用户
    path('ad_message_result',views.ad_message_result)   #消息发送成功页面

]
