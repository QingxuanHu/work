create database bookmanagement;
use bookmanagement;

User
create table User (  
  ID varchar(10) not null ,
  name varchar(10) not null ,
  password varchar(20) not null ,
  identity varchar(10) not null ,
  sex varchar(10) not null,
  institude varchar(20) not null,
  record int check(record >= 0) not null,
  fine int check(fine >= 0) not null,
  remain_num int check(remainNum >= 0) not null,  
  primary key(ID)
); 

insert User values('000001','Mike','000001','Student','M','Computer',0,0,3); 
insert User values('000002','Jack','000002','Student','M','Chemistry',0,0,3); 
insert User values('000004','Lucy','000004','Student','F','Design',0,0,3); 
insert User values('000006','Paul','000006','Student','M','Software',0,0,3); 
insert User values('000008','Curry','000008','Student','M','Sport',0,0,3); 
insert User values('000009','Jordan','000009','Student','M','Business',0,0,3); 
insert User values('000010','Young','000010','Student','M','Food',0,0,3);

Administer
create table Administrator (  
  ID varchar(10) not null ,
  Name varchar(10) not null ,
  password varchar(20) not null ,  
  primary key(ID)
); 
insert Administrator values('001','Philip','201901'); 
insert Administrator values('002','Jason','201902'); 
insert Administrator values('003','Tomas','201903');

Book
create table Book (  
  ID varchar(10) not null ,
  Name varchar(10) not null ,
  Author varchar(20) not null ,
  is_borrow varchar(10) not null ,  
  primary key(ID)
); 
insert Book values('0001','战争与和平','George,James','false'); 
insert Book values('0002','战争与和平','George,James','false');
insert Book values('0003','战争与和平','George,James','false');
insert Book values('0004','老人与海','Luca','false');
insert Book values('0005','老人与海','Luca','false');
insert Book values('0006','迪迦奥特曼','Wen','false');
insert Book values('0007','赛尔号','Change','false');
insert Book values('0008','增广贤文','Kong','false');

Borrow
create table Borrow (  
  User_ID varchar(10) not null ,
  User_Name varchar(10) not null ,
  Book_ID varchar(10) not null ,
  Book_Name varchar(10) not null ,
  BorrowING_Time varchar(20) not null,
  is_overtime varchar(10) not null,
  foreign key(User_ID) references User(ID),
  foreign key(Book_ID) references Book(ID)
); 

Comment
create table Comment (  
  User_ID varchar(10) not null ,
  User_Name varchar(10) not null ,
  Book_ID varchar(10) not null ,
  Book_Name varchar(10) not null ,
  comment varchar(100) not null,
  foreign key(User_ID) references User(ID),
  foreign key(Book_ID) references Book(ID)
); 

Message
create table Message (  
  User_ID varchar(10) not null ,
  User_Name varchar(10) not null ,
  Ad_ID varchar(10) not null ,
  Ad_Name varchar(10) not null ,
  Text varchar(100) not null,
  Time varchar(20) not null,
  foreign key(User_ID) references User(ID),
  foreign key(Ad_ID) references Administrator(ID)
);
